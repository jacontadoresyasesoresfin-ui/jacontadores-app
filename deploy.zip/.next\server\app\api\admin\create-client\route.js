var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/admin/create-client/route.js")
R.c("server/chunks/[root-of-the-server]__2ea64789._.js")
R.c("server/chunks/node_modules_@supabase_supabase-js_dist_index_mjs_669a44bf._.js")
R.c("server/chunks/[root-of-the-server]__f408c708._.js")
R.c("server/chunks/_next-internal_server_app_api_admin_create-client_route_actions_c72fda71.js")
R.m(9681)
module.exports=R.m(9681).exports
