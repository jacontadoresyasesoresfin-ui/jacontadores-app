var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/admin/delete-user/route.js")
R.c("server/chunks/[root-of-the-server]__a5f3cc02._.js")
R.c("server/chunks/node_modules_@supabase_supabase-js_dist_index_mjs_669a44bf._.js")
R.c("server/chunks/[root-of-the-server]__f408c708._.js")
R.c("server/chunks/_next-internal_server_app_api_admin_delete-user_route_actions_250129ee.js")
R.m(88957)
module.exports=R.m(88957).exports
