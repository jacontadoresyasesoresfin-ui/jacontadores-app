var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/ecommerce/route.js")
R.c("server/chunks/[root-of-the-server]__fe8fd6f3._.js")
R.c("server/chunks/node_modules_@supabase_supabase-js_dist_index_mjs_669a44bf._.js")
R.c("server/chunks/[root-of-the-server]__f408c708._.js")
R.c("server/chunks/_next-internal_server_app_api_ecommerce_route_actions_6742ae06.js")
R.m(13521)
module.exports=R.m(13521).exports
