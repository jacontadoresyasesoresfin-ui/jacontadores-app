var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/sheets-proxy/route.js")
R.c("server/chunks/[root-of-the-server]__35e01e9f._.js")
R.c("server/chunks/[root-of-the-server]__f408c708._.js")
R.c("server/chunks/_next-internal_server_app_api_sheets-proxy_route_actions_9e3d4462.js")
R.m(70166)
module.exports=R.m(70166).exports
