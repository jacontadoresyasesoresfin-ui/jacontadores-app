module.exports=[55832,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_admin_create-client_route_actions_c72fda71.js.map