module.exports=[4263,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_admin_create-collaborator_route_actions_2cf82435.js.map