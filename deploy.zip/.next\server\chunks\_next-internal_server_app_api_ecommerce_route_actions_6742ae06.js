module.exports=[22750,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_ecommerce_route_actions_6742ae06.js.map