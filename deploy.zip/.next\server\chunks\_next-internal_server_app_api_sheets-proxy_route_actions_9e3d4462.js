module.exports=[45021,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_sheets-proxy_route_actions_9e3d4462.js.map