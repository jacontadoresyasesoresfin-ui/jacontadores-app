module.exports=[95561,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_dashboard_ecommerce_page_actions_81a3f424.js.map