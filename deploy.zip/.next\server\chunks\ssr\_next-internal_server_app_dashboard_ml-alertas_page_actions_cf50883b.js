module.exports=[71908,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_dashboard_ml-alertas_page_actions_cf50883b.js.map