module.exports=[80798,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_dashboard_ml-comisiones_page_actions_95cf795f.js.map