module.exports=[67170,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_dashboard_ml-devoluciones_page_actions_9a9eed32.js.map