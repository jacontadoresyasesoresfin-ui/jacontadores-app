module.exports=[35441,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_dashboard_siigo_page_actions_3a615146.js.map