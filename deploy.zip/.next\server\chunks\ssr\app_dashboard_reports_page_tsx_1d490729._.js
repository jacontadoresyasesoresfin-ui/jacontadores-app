module.exports=[1771,a=>{"use strict";var b=a.i(87924),c=a.i(72131);let d=(0,a.i(70106).default)("download",[["path",{d:"M12 15V3",key:"m9g1x1"}],["path",{d:"M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4",key:"ih7n3h"}],["path",{d:"m7 10 5 5 5-5",key:"brsn70"}]]);var e=a.i(4720),f=a.i(24669),g=a.i(90166),h=a.i(38784),i=a.i(60246),j=a.i(77156),k=a.i(96221),l=a.i(41016);let m=a=>`COP $${Math.round(a).toLocaleString("es-CO")}`,n=(a,b,c)=>`
  <div style="display:flex;align-items:flex-start;justify-content:space-between;margin-bottom:24px;padding-bottom:16px;border-bottom:3px solid #14B8A6;">
    <div>
      <div style="font-size:11px;color:#888;letter-spacing:2px;font-weight:700;text-transform:uppercase;margin-bottom:4px;">J&amp;A CONTADORES - CONSULTORES</div>
      <h1 style="margin:0;font-size:26px;font-weight:900;color:#0B0E11;">${a}</h1>
      <p style="margin:4px 0 0;font-size:13px;color:#555;">${b}</p>
    </div>
    <div style="text-align:right;">
      <div style="font-size:13px;font-weight:700;color:#0B0E11;">${c}</div>
      <div style="font-size:11px;color:#888;margin-top:4px;">Generado: ${new Date().toLocaleDateString("es-CO",{year:"numeric",month:"long",day:"numeric"})}</div>
      <div style="font-size:11px;color:#888;">${new Date().toLocaleTimeString("es-CO",{hour:"2-digit",minute:"2-digit"})}</div>
    </div>
  </div>
`,o=()=>`
  <div style="margin-top:40px;padding-top:12px;border-top:1px solid #ddd;display:flex;justify-content:space-between;font-size:10px;color:#999;">
    <span>J&amp;A Contadores - Consultores — Informe generado autom\xe1ticamente desde datos reales</span>
    <span>P\xe1gina 1 de 1</span>
  </div>
`,p=`
  <style>
    * { box-sizing: border-box; margin: 0; padding: 0; }
    body { font-family: 'Segoe UI', Arial, sans-serif; font-size: 13px; color: #222; background: #fff; padding: 32px 40px; }
    h2 { font-size: 16px; font-weight: 800; color: #0B0E11; margin: 24px 0 12px; letter-spacing: -0.3px; }
    h3 { font-size: 13px; font-weight: 700; color: #444; margin: 16px 0 8px; }
    table { width: 100%; border-collapse: collapse; margin-bottom: 16px; }
    th { background: #0B2447; color: #FFFFFF; font-weight: 800; font-size: 11px; text-transform: uppercase; letter-spacing: 0.5px; padding: 8px 10px; text-align: left; }
    td { padding: 7px 10px; border-bottom: 1px solid #f0f0f0; color: #333; font-size: 12px; }
    tr:nth-child(even) td { background: #fafafa; }
    .badge { display:inline-block; padding:2px 8px; border-radius:12px; font-size:10px; font-weight:700; }
    .badge-green { background:#d1fae5; color:#065f46; }
    .badge-yellow { background:#fef3c7; color:#92400e; }
    .badge-red { background:#fee2e2; color:#991b1b; }
    .kpi-grid { display:grid; grid-template-columns:repeat(4,1fr); gap:12px; margin-bottom:24px; }
    .kpi-card { background:#f8f8f8; border:1px solid #e8e8e8; border-radius:8px; padding:14px 16px; }
    .kpi-label { font-size:10px; font-weight:700; text-transform:uppercase; letter-spacing:1px; color:#888; margin-bottom:4px; }
    .kpi-value { font-size:18px; font-weight:900; color:#0B0E11; }
    .kpi-change-up { font-size:11px; color:#059669; font-weight:600; margin-top:4px; }
    .kpi-change-down { font-size:11px; color:#dc2626; font-weight:600; margin-top:4px; }
    .alert-box { background:#fffbeb; border:1px solid #fcd34d; border-radius:6px; padding:10px 14px; margin:4px 0; font-size:12px; color:#78350f; }
    @media print {
      body { padding: 20px 28px; }
      @page { margin: 1cm; }
    }
  </style>
`;function q(a,b=!0){let c=window.open("","_blank");c?(c.document.write(`<!DOCTYPE html><html lang="es"><head><meta charset="UTF-8">${p}<title>Informe J&A Contadores</title></head><body>${a}</body></html>`),c.document.close(),b&&(c.onload=()=>{c.focus(),c.print()},setTimeout(()=>{c.closed||(c.focus(),c.print())},800))):alert("Permite las ventanas emergentes para generar el informe.")}let r="#14B8A6",s="#0B2447",t="#10B981",u={background:"#FFFFFF",border:"1.5px solid #E2E8F0",borderRadius:"16px",boxShadow:"0 2px 12px rgba(15,23,42,0.06)",padding:"20px"};function v(){let{data:a,clientName:p,loading:v}=(0,l.useClient)(),[w,x]=(0,c.useState)("month"),[y,z]=(0,c.useState)(null);if(v||!a)return(0,b.jsxs)("div",{className:"p-8 flex items-center gap-3 text-slate-600",children:[(0,b.jsx)("div",{className:"w-5 h-5 border-2 rounded-full animate-spin",style:{borderColor:`${r}40`,borderTopColor:r}}),"Cargando Reportes..."]});let A=(b,c)=>{z(b),setTimeout(()=>{let d=p||"Mi Empresa";1===b?function(a,b,c,d=!0){let e=a.salesHistory.slice(-20).map(a=>`
    <tr><td>${a.date}</td><td style="text-align:right;font-weight:600;">${m(a.amount)}</td></tr>
  `).join(""),f=a.recurringCustomers.map((a,b)=>`
    <tr>
      <td>${b+1}</td>
      <td style="font-weight:600;">${a.name}</td>
      <td style="text-align:center;">${a.count}</td>
      <td style="text-align:right;font-weight:700;color:#059669;">${m(a.total)}</td>
    </tr>
  `).join(""),g=a.topProducts.map((a,b)=>`
    <tr>
      <td>${b+1}</td>
      <td style="font-weight:600;">${a.name}</td>
      <td style="text-align:center;">${a.count}</td>
      <td style="text-align:right;font-weight:700;">${m(a.total)}</td>
    </tr>
  `).join("");q(`
    ${n("Reporte de Ventas",`Per\xedodo: ${"week"===c?"Semana actual":"month"===c?"Mes actual":"Año actual"}`,b)}

    <div class="kpi-grid">
      <div class="kpi-card">
        <div class="kpi-label">Ventas Totales</div>
        <div class="kpi-value" style="font-size:15px;">${a.metrics.sales.value}</div>
        <div class="kpi-change-up">↑ ${a.metrics.sales.change}% vs per\xedodo anterior</div>
      </div>
      <div class="kpi-card">
        <div class="kpi-label">Facturas Emitidas</div>
        <div class="kpi-value">${a.metrics.productsSold.value}</div>
        <div class="kpi-change-up">↑ ${a.metrics.productsSold.change}%</div>
      </div>
      <div class="kpi-card">
        <div class="kpi-label">Clientes \xdanicos</div>
        <div class="kpi-value">${a.metrics.newClients.value}</div>
        <div class="kpi-change-up">↑ ${a.metrics.newClients.change}%</div>
      </div>
      <div class="kpi-card">
        <div class="kpi-label">Proyecci\xf3n 30 d\xedas</div>
        <div class="kpi-value" style="font-size:14px;">${m(a.prediction.nextMonth)}</div>
        <div class="kpi-change-up">Crecimiento: ${a.prediction.growthRate.toFixed(1)}%</div>
      </div>
    </div>

    <h2>Historial de Ventas (\xfaltimas 20 fechas)</h2>
    <table>
      <thead><tr><th>Fecha</th><th style="text-align:right;">Monto</th></tr></thead>
      <tbody>${e||'<tr><td colspan="2" style="text-align:center;color:#888;">Sin datos de historial</td></tr>'}</tbody>
    </table>

    <div style="display:grid;grid-template-columns:1fr 1fr;gap:20px;margin-top:8px;">
      <div>
        <h2>Top Clientes por Facturaci\xf3n</h2>
        <table>
          <thead><tr><th>#</th><th>Cliente</th><th style="text-align:center;">Facturas</th><th style="text-align:right;">Total</th></tr></thead>
          <tbody>${f||'<tr><td colspan="4" style="text-align:center;color:#888;">Sin datos</td></tr>'}</tbody>
        </table>
      </div>
      <div>
        <h2>Top Productos / Servicios</h2>
        <table>
          <thead><tr><th>#</th><th>Descripci\xf3n</th><th style="text-align:center;">Cant.</th><th style="text-align:right;">Total</th></tr></thead>
          <tbody>${g||'<tr><td colspan="4" style="text-align:center;color:#888;">Sin datos</td></tr>'}</tbody>
        </table>
      </div>
    </div>

    ${o()}
  `,d)}(a,d,w,c):2===b?function(a,b,c=!0){let d=a.taxData,e=d.monthlyBreakdown.map(a=>`
    <tr>
      <td style="font-weight:600;">${a.month}</td>
      <td style="text-align:right;">${m(a.ventas)}</td>
      <td style="text-align:right;">${m(a.iva)}</td>
      <td style="text-align:right;">${m(a.reteFuente)}</td>
      <td style="text-align:right;">${m(a.reteICA)}</td>
      <td style="text-align:right;font-weight:700;color:#059669;">${m(a.neto)}</td>
    </tr>
  `).join("");q(`
    ${n("Estado Financiero","Resumen de resultados y cartera",b)}

    <div class="kpi-grid">
      <div class="kpi-card">
        <div class="kpi-label">Ventas Brutas</div>
        <div class="kpi-value" style="font-size:14px;">${m(d.totalVentasBruto)}</div>
      </div>
      <div class="kpi-card">
        <div class="kpi-label">Impuestos Totales</div>
        <div class="kpi-value" style="font-size:14px;color:#dc2626;">${m(d.totalImpuestosCargo)}</div>
      </div>
      <div class="kpi-card">
        <div class="kpi-label">Cartera Total (Est.)</div>
        <div class="kpi-value" style="font-size:14px;">${a.portfolio.total}</div>
      </div>
      <div class="kpi-card">
        <div class="kpi-label">Cartera Vencida</div>
        <div class="kpi-value" style="font-size:14px;color:#dc2626;">${a.metrics.overdue.value}</div>
      </div>
    </div>

    <h2>Estado de Cartera</h2>
    <table>
      <thead><tr><th>Categor\xeda</th><th style="text-align:right;">Valor</th><th style="text-align:right;">%</th><th>Estado</th></tr></thead>
      <tbody>
        <tr><td>Cartera Vigente</td><td style="text-align:right;">${a.portfolio.current.value}</td><td style="text-align:right;">${a.portfolio.current.percent}%</td><td><span class="badge badge-green">✓ Al d\xeda</span></td></tr>
        <tr><td>Por Vencer</td><td style="text-align:right;">${a.portfolio.dueSoon.value}</td><td style="text-align:right;">${a.portfolio.dueSoon.percent}%</td><td><span class="badge badge-yellow">⚠ Pr\xf3xima</span></td></tr>
        <tr><td>Cartera Vencida</td><td style="text-align:right;">${a.portfolio.overdue.value}</td><td style="text-align:right;">${a.portfolio.overdue.percent}%</td><td><span class="badge badge-red">✗ Vencida</span></td></tr>
      </tbody>
    </table>

    <h2>Desglose Mensual</h2>
    <table>
      <thead><tr><th>Mes</th><th style="text-align:right;">Ventas</th><th style="text-align:right;">IVA</th><th style="text-align:right;">ReteFuente</th><th style="text-align:right;">ReteICA</th><th style="text-align:right;">Neto</th></tr></thead>
      <tbody>${e||'<tr><td colspan="6" style="text-align:center;color:#888;">Sin datos mensuales</td></tr>'}</tbody>
    </table>

    <h2>Proyecci\xf3n Financiera</h2>
    <table>
      <thead><tr><th>Indicador</th><th style="text-align:right;">Valor</th></tr></thead>
      <tbody>
        <tr><td>Proyecci\xf3n ventas pr\xf3ximos 30 d\xedas</td><td style="text-align:right;font-weight:700;">${m(a.prediction.nextMonth)}</td></tr>
        <tr><td>Tasa de crecimiento estimada</td><td style="text-align:right;font-weight:700;">${a.prediction.growthRate.toFixed(2)}%</td></tr>
        <tr><td>Tasa efectiva tributaria</td><td style="text-align:right;font-weight:700;">${d.tasaEfectivaTributaria}%</td></tr>
        <tr><td>Base gravable renta estimada</td><td style="text-align:right;font-weight:700;">${m(d.baseGravableRenta)}</td></tr>
        <tr><td>Impuesto de renta estimado (35%)</td><td style="text-align:right;font-weight:700;color:#dc2626;">${m(d.impuestoRentaEstimado)}</td></tr>
      </tbody>
    </table>

    ${o()}
  `,c)}(a,d,c):3===b?function(a,b,c=!0){let d=a.recurringCustomers.map((a,b)=>`
    <tr>
      <td>${b+1}</td>
      <td style="font-weight:600;">${a.name}</td>
      <td style="text-align:center;">${a.count}</td>
      <td style="text-align:right;">${m(a.total)}</td>
      <td style="text-align:right;">${m(a.total/Math.max(a.count,1))}</td>
    </tr>
  `).join(""),e=a.metrics.sales.rawValue;q(`
    ${n("Análisis de Clientes","Segmentación y comportamiento de clientes",b)}

    <div class="kpi-grid">
      <div class="kpi-card">
        <div class="kpi-label">Clientes \xdanicos</div>
        <div class="kpi-value">${a.metrics.newClients.value}</div>
      </div>
      <div class="kpi-card">
        <div class="kpi-label">Clientes Recurrentes</div>
        <div class="kpi-value">${a.recurringCustomers.filter(a=>a.count>1).length}</div>
      </div>
      <div class="kpi-card">
        <div class="kpi-label">Facturaci\xf3n Total</div>
        <div class="kpi-value" style="font-size:14px;">${a.metrics.sales.value}</div>
      </div>
      <div class="kpi-card">
        <div class="kpi-label">Ticket Promedio</div>
        <div class="kpi-value" style="font-size:14px;">${m(e/Math.max(a.metrics.productsSold.rawValue,1))}</div>
      </div>
    </div>

    <h2>Ranking de Clientes por Facturaci\xf3n</h2>
    <table>
      <thead>
        <tr>
          <th>#</th>
          <th>Nombre / Raz\xf3n Social</th>
          <th style="text-align:center;">Facturas</th>
          <th style="text-align:right;">Total Facturado</th>
          <th style="text-align:right;">Ticket Promedio</th>
        </tr>
      </thead>
      <tbody>${d||'<tr><td colspan="5" style="text-align:center;color:#888;">Sin datos de clientes</td></tr>'}</tbody>
    </table>

    <h2>Actividad Reciente</h2>
    <table>
      <thead><tr><th>Fecha</th><th>Cliente</th><th>Tipo</th><th style="text-align:right;">Monto</th></tr></thead>
      <tbody>
        ${a.recentActivity.map(a=>`
          <tr>
            <td>${a.time}</td>
            <td style="font-weight:600;">${a.client}</td>
            <td>${a.text}</td>
            <td style="text-align:right;font-weight:700;color:#059669;">${a.amount}</td>
          </tr>
        `).join("")}
      </tbody>
    </table>

    ${o()}
  `,c)}(a,d,c):4===b&&function(a,b,c=!0){let d=a.taxData,e=d.alertas.map(a=>`<div class="alert-box">${a}</div>`).join("");q(`
    ${n("Informe Tributario","Obligaciones fiscales estimadas — Ley Colombiana",b)}

    <div style="background:#fffbeb;border:2px solid #F0B90B;border-radius:8px;padding:10px 16px;margin-bottom:20px;font-size:11px;color:#78350f;">
      ⚠️ Este informe es una <strong>estimaci\xf3n referencial</strong>. Los valores no reemplazan una declaraci\xf3n oficial ante la DIAN. Cons\xfaltelo con su contador.
    </div>

    <div class="kpi-grid">
      <div class="kpi-card">
        <div class="kpi-label">Total Ventas Brutas</div>
        <div class="kpi-value" style="font-size:14px;">${m(d.totalVentasBruto)}</div>
      </div>
      <div class="kpi-card">
        <div class="kpi-label">IVA Generado</div>
        <div class="kpi-value" style="font-size:14px;">${m(d.totalIVACobrado)}</div>
      </div>
      <div class="kpi-card">
        <div class="kpi-label">IVA a Pagar (Est.)</div>
        <div class="kpi-value" style="font-size:14px;color:#dc2626;">${m(d.totalIVAPorPagar)}</div>
      </div>
      <div class="kpi-card">
        <div class="kpi-label">Tasa Efectiva</div>
        <div class="kpi-value">${d.tasaEfectivaTributaria}%</div>
      </div>
    </div>

    <h2>Resumen de Impuestos</h2>
    <table>
      <thead><tr><th>Impuesto</th><th>Base</th><th style="text-align:right;">Valor Estimado</th></tr></thead>
      <tbody>
        <tr><td>IVA Cobrado (19%)</td><td>Sobre ventas</td><td style="text-align:right;font-weight:700;">${m(d.totalIVACobrado)}</td></tr>
        <tr><td>IVA a Pagar (neto)</td><td>Cobrado - Descontable</td><td style="text-align:right;font-weight:700;color:#dc2626;">${m(d.totalIVAPorPagar)}</td></tr>
        <tr><td>Retenci\xf3n en la Fuente (3.5%)</td><td>Sobre ventas base</td><td style="text-align:right;font-weight:700;">${m(d.totalReteFuente)}</td></tr>
        <tr><td>ReteIVA (15%)</td><td>Sobre IVA</td><td style="text-align:right;font-weight:700;">${m(d.totalReteIVA)}</td></tr>
        <tr><td>ReteICA Bogot\xe1 (4.14‰)</td><td>Actividades comerciales</td><td style="text-align:right;font-weight:700;">${m(d.totalReteICA)}</td></tr>
        <tr style="background:#fff3cd;"><td style="font-weight:700;">Total Impuestos Cargo</td><td>—</td><td style="text-align:right;font-weight:900;color:#dc2626;">${m(d.totalImpuestosCargo)}</td></tr>
      </tbody>
    </table>

    <h2>Impuesto de Renta (Estimado)</h2>
    <table>
      <thead><tr><th>Concepto</th><th style="text-align:right;">Valor</th></tr></thead>
      <tbody>
        <tr><td>Base Gravable</td><td style="text-align:right;">${m(d.baseGravableRenta)}</td></tr>
        <tr><td>Impuesto de Renta estimado (35%)</td><td style="text-align:right;font-weight:700;color:#dc2626;">${m(d.impuestoRentaEstimado)}</td></tr>
        <tr><td>R\xe9gimen Sugerido</td><td style="text-align:right;font-weight:700;">${d.regimenSugerido}</td></tr>
      </tbody>
    </table>

    <h2>Declaraciones Peri\xf3dicas</h2>
    <table>
      <thead><tr><th>Tipo</th><th style="text-align:right;">Valor Estimado</th></tr></thead>
      <tbody>
        <tr><td>IVA Bimestral (promedio)</td><td style="text-align:right;font-weight:700;">${m(d.ivaDeclaracionBimestral)}</td></tr>
        <tr><td>IVA Cuatrimestral (promedio)</td><td style="text-align:right;font-weight:700;">${m(d.ivaDeclaracionCuatrimestral)}</td></tr>
        <tr><td>Total Facturas analizadas</td><td style="text-align:right;">${d.totalFacturas}</td></tr>
      </tbody>
    </table>

    ${d.alertas.length>0?`<h2>Alertas y Recomendaciones</h2>${e}`:""}

    ${o()}
  `,c)}(a,d,c),z(null)},100)},B=[{id:1,title:"Reporte de Ventas",description:"Análisis detallado de ventas, historial y top clientes por período",icon:h.ShoppingCart,color:r,bgColor:"#CCFBF1",lastGenerated:new Date().toLocaleDateString(),dataPoints:`${a.metrics.productsSold.value} facturas \xb7 ${a.metrics.newClients.value} clientes`},{id:2,title:"Estado Financiero",description:"Resumen de cartera, métricas financieras y proyección de ingresos",icon:g.DollarSign,color:s,bgColor:"#E0F2FE",lastGenerated:new Date().toLocaleDateString(),dataPoints:`Cartera: ${a.portfolio.total} \xb7 ${a.portfolio.current.percent}% al d\xeda`},{id:3,title:"Análisis de Clientes",description:"Segmentación, recurrencia y comportamiento de clientes por facturación",icon:i.Users,color:t,bgColor:"#D1FAE5",lastGenerated:new Date().toLocaleDateString(),dataPoints:`${a.recurringCustomers.length} clientes analizados`},{id:4,title:"Informe Tributario",description:"Estimación de IVA, retenciones y renta anual según Ley Colombiana",icon:f.TrendingUp,color:"#D4A843",bgColor:"#FEF3C7",lastGenerated:new Date().toLocaleDateString(),dataPoints:`IVA: ${(a.taxData.totalIVACobrado/1e6).toFixed(1)}M \xb7 Renta est.`}],C=[{label:"Ventas Totales",value:a.metrics.sales.value,color:r,bgColor:"#CCFBF1",icon:g.DollarSign},{label:"Facturas Generadas",value:a.metrics.productsSold.value,color:s,bgColor:"#E0F2FE",icon:e.FileText},{label:"Clientes Activos",value:a.metrics.newClients.value,color:t,bgColor:"#D1FAE5",icon:i.Users},{label:"Cartera Vencida",value:a.portfolio.overdue.value,color:"#EF4444",bgColor:"#FEE2E2",icon:f.TrendingUp}];return(0,b.jsxs)("div",{className:"space-y-6 pb-10",style:{fontFamily:"var(--font-inter)"},children:[(0,b.jsxs)("div",{className:"flex flex-col sm:flex-row sm:items-center justify-between gap-4",children:[(0,b.jsxs)("div",{children:[(0,b.jsxs)("h1",{className:"text-2xl font-black text-slate-800",style:{fontFamily:"var(--font-outfit)"},children:["Centro de ",(0,b.jsx)("span",{style:{color:r},children:"Reportes"})]}),(0,b.jsx)("p",{className:"text-slate-400 text-sm mt-1",children:"Genera informes financieros completos en PDF — datos reales del cliente"})]}),(0,b.jsx)("div",{className:"flex items-center gap-1 p-1 rounded-xl",style:{background:"#F8FAFC",border:"1.5px solid #E2E8F0"},children:[{id:"week",label:"Esta Semana"},{id:"month",label:"Este Mes"},{id:"year",label:"Este Año"}].map(a=>(0,b.jsx)("button",{onClick:()=>x(a.id),className:"px-3 py-1.5 text-xs font-bold rounded-lg transition-all",style:w===a.id?{background:s,color:"white",boxShadow:"0 2px 8px rgba(11,36,71,0.3)"}:{color:"#64748B"},children:a.label},a.id))})]}),(0,b.jsx)("div",{className:"grid grid-cols-2 lg:grid-cols-4 gap-4",children:C.map((a,c)=>(0,b.jsxs)("div",{style:u,className:"hover:-translate-y-0.5 transition-transform",children:[(0,b.jsxs)("div",{className:"flex items-center justify-between mb-3",children:[(0,b.jsx)("p",{className:"text-slate-400 text-[10px] uppercase font-bold tracking-wider",children:a.label}),(0,b.jsx)("div",{className:"w-8 h-8 rounded-lg flex items-center justify-center",style:{background:a.bgColor},children:(0,b.jsx)(a.icon,{className:"w-4 h-4",style:{color:a.color}})})]}),(0,b.jsx)("p",{className:"font-black text-xl font-mono",style:{color:a.color},children:a.value})]},c))}),(0,b.jsx)("div",{className:"grid grid-cols-1 md:grid-cols-2 gap-5",children:B.map(a=>{let c=a.icon,e=y===a.id;return(0,b.jsx)("div",{style:u,className:"group hover:-translate-y-1 transition-all duration-200 hover:shadow-lg",children:(0,b.jsxs)("div",{className:"flex items-start gap-4",children:[(0,b.jsx)("div",{className:"w-12 h-12 rounded-2xl flex items-center justify-center flex-shrink-0 transition-transform group-hover:scale-110 duration-300",style:{background:a.bgColor},children:(0,b.jsx)(c,{className:"w-6 h-6",style:{color:a.color}})}),(0,b.jsxs)("div",{className:"flex-1 min-w-0",children:[(0,b.jsx)("h3",{className:"font-black text-slate-800 text-base mb-1",children:a.title}),(0,b.jsx)("p",{className:"text-slate-500 text-xs leading-relaxed mb-3",children:a.description}),(0,b.jsxs)("div",{className:"flex items-center gap-2 flex-wrap mb-4",children:[(0,b.jsxs)("span",{className:"text-[9px] px-2 py-0.5 rounded-full font-bold",style:{background:"#F1F5F9",color:"#64748B"},children:["📊 ",a.dataPoints]}),(0,b.jsxs)("span",{className:"text-[9px] text-slate-400",children:["Generado: ",a.lastGenerated]})]}),(0,b.jsxs)("div",{className:"flex items-center gap-2",children:[(0,b.jsx)("button",{onClick:()=>A(a.id,!1),disabled:e,className:"flex items-center gap-1.5 px-3 py-2 text-xs font-bold rounded-xl transition-all hover:opacity-90 active:scale-95 disabled:opacity-50",style:{background:a.color,color:"white",boxShadow:`0 4px 12px ${a.color}40`},children:e?(0,b.jsxs)(b.Fragment,{children:[(0,b.jsx)(k.Loader2,{className:"w-3.5 h-3.5 animate-spin"})," Generando..."]}):(0,b.jsxs)(b.Fragment,{children:[(0,b.jsx)(j.Eye,{className:"w-3.5 h-3.5"})," Vista Previa"]})}),(0,b.jsxs)("button",{onClick:()=>A(a.id,!0),disabled:e,className:"flex items-center gap-1.5 px-3 py-2 text-xs font-bold rounded-xl transition-all hover:bg-slate-100 active:scale-95 disabled:opacity-50",style:{background:"#F8FAFC",color:"#64748B",border:"1.5px solid #E2E8F0"},children:[(0,b.jsx)(d,{className:"w-3.5 h-3.5"})," Imprimir PDF"]})]})]})]})},a.id)})}),(0,b.jsxs)("div",{style:u,children:[(0,b.jsxs)("div",{className:"flex items-center justify-between mb-4",children:[(0,b.jsx)("h3",{className:"font-bold text-slate-800 text-sm",children:"Actividad Reciente del Cliente"}),(0,b.jsxs)("span",{className:"text-[10px] font-bold px-2 py-0.5 rounded-lg",style:{background:"#CCFBF1",color:"#0F766E"},children:["Últimas ",a.recentActivity.length," transacciones"]})]}),(0,b.jsx)("div",{className:"space-y-2",children:a.recentActivity.length>0?a.recentActivity.map((a,c)=>(0,b.jsxs)("div",{className:"flex items-center justify-between p-3 rounded-xl hover:bg-slate-50 transition-colors",style:{border:"1px solid #F1F5F9"},children:[(0,b.jsxs)("div",{className:"flex items-center gap-3 min-w-0",children:[(0,b.jsx)("div",{className:"w-8 h-8 rounded-xl flex items-center justify-center flex-shrink-0",style:{background:`${r}15`},children:(0,b.jsx)("div",{className:"w-2 h-2 rounded-full",style:{background:r}})}),(0,b.jsxs)("div",{className:"min-w-0",children:[(0,b.jsx)("p",{className:"text-slate-700 text-sm font-semibold truncate",children:a.text}),(0,b.jsx)("p",{className:"text-slate-400 text-xs truncate",children:a.client})]})]}),(0,b.jsxs)("div",{className:"text-right flex-shrink-0 ml-4",children:[(0,b.jsx)("p",{className:"font-black text-sm font-mono",style:{color:r},children:a.amount}),(0,b.jsx)("p",{className:"text-slate-400 text-xs",children:a.time})]})]},c)):(0,b.jsx)("div",{className:"text-center py-8 text-slate-400 text-sm",children:"Sin actividad reciente registrada"})})]})]})}a.s(["default",()=>v],1771)}];

//# sourceMappingURL=app_dashboard_reports_page_tsx_1d490729._.js.map