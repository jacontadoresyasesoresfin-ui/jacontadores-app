var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/drive-sync/route.js")
R.c("server/chunks/[root-of-the-server]__f508bf4f._.js")
R.c("server/chunks/[root-of-the-server]__e2921b21._.js")
R.c("server/chunks/[root-of-the-server]__f408c708._.js")
R.c("server/chunks/_next-internal_server_app_api_drive-sync_route_actions_657a0b93.js")
R.m(88461)
module.exports=R.m(88461).exports
