globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/a6dad97d9634a72d.js"
  ],
  "lowPriorityFiles": [],
  "rootMainFiles": [
    "static/chunks/cac5d456dc7f52db.js",
    "static/chunks/da58c3fb52900311.js",
    "static/chunks/6616f1a35d904b9b.js",
    "static/chunks/e1dcafe2376ff124.js",
    "static/chunks/d41ea3757dc50657.js",
    "static/chunks/turbopack-cf0985d2eeb96c2b.js"
  ]
};
globalThis.__BUILD_MANIFEST.lowPriorityFiles = [
"/static/" + process.env.__NEXT_BUILD_ID + "/_buildManifest.js",
"/static/" + process.env.__NEXT_BUILD_ID + "/_ssgManifest.js"
];