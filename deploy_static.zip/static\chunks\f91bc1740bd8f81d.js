(globalThis.TURBOPACK||(globalThis.TURBOPACK=[])).push(["object"==typeof document?document.currentScript:void 0,86536,t=>{"use strict";let e=(0,t.i(75254).default)("eye",[["path",{d:"M2.062 12.348a1 1 0 0 1 0-.696 10.75 10.75 0 0 1 19.876 0 1 1 0 0 1 0 .696 10.75 10.75 0 0 1-19.876 0",key:"1nclc0"}],["circle",{cx:"12",cy:"12",r:"3",key:"1v7zrd"}]]);t.s(["Eye",()=>e],86536)},31278,t=>{"use strict";let e=(0,t.i(75254).default)("loader-circle",[["path",{d:"M21 12a9 9 0 1 1-6.219-8.56",key:"13zald"}]]);t.s(["Loader2",()=>e],31278)},8112,t=>{"use strict";var e=t.i(43476),a=t.i(71645);let i=(0,t.i(75254).default)("download",[["path",{d:"M12 15V3",key:"m9g1x1"}],["path",{d:"M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4",key:"ih7n3h"}],["path",{d:"m7 10 5 5 5-5",key:"brsn70"}]]);var l=t.i(78583),s=t.i(25652),d=t.i(12426),r=t.i(1928),o=t.i(61911),n=t.i(86536),c=t.i(31278),p=t.i(38768);let x=t=>`COP $${Math.round(t).toLocaleString("es-CO")}`,g=(t,e,a)=>`
  <div style="display:flex;align-items:flex-start;justify-content:space-between;margin-bottom:24px;padding-bottom:16px;border-bottom:3px solid #14B8A6;">
    <div>
      <div style="font-size:11px;color:#888;letter-spacing:2px;font-weight:700;text-transform:uppercase;margin-bottom:4px;">J&amp;A CONTADORES - CONSULTORES</div>
      <h1 style="margin:0;font-size:26px;font-weight:900;color:#0B0E11;">${t}</h1>
      <p style="margin:4px 0 0;font-size:13px;color:#555;">${e}</p>
    </div>
    <div style="text-align:right;">
      <div style="font-size:13px;font-weight:700;color:#0B0E11;">${a}</div>
      <div style="font-size:11px;color:#888;margin-top:4px;">Generado: ${new Date().toLocaleDateString("es-CO",{year:"numeric",month:"long",day:"numeric"})}</div>
      <div style="font-size:11px;color:#888;">${new Date().toLocaleTimeString("es-CO",{hour:"2-digit",minute:"2-digit"})}</div>
    </div>
  </div>
`,h=()=>`
  <div style="margin-top:40px;padding-top:12px;border-top:1px solid #ddd;display:flex;justify-content:space-between;font-size:10px;color:#999;">
    <span>J&amp;A Contadores - Consultores — Informe generado autom\xe1ticamente desde datos reales</span>
    <span>P\xe1gina 1 de 1</span>
  </div>
`,m=`
  <style>
    * { box-sizing: border-box; margin: 0; padding: 0; }
    body { font-family: 'Segoe UI', Arial, sans-serif; font-size: 13px; color: #222; background: #fff; padding: 32px 40px; }
    h2 { font-size: 16px; font-weight: 800; color: #0B0E11; margin: 24px 0 12px; letter-spacing: -0.3px; }
    h3 { font-size: 13px; font-weight: 700; color: #444; margin: 16px 0 8px; }
    table { width: 100%; border-collapse: collapse; margin-bottom: 16px; }
    th { background: #0B2447; color: #FFFFFF; font-weight: 800; font-size: 11px; text-transform: uppercase; letter-spacing: 0.5px; padding: 8px 10px; text-align: left; }
    td { padding: 7px 10px; border-bottom: 1px solid #f0f0f0; color: #333; font-size: 12px; }
    tr:nth-child(even) td { background: #fafafa; }
    .badge { display:inline-block; padding:2px 8px; border-radius:12px; font-size:10px; font-weight:700; }
    .badge-green { background:#d1fae5; color:#065f46; }
    .badge-yellow { background:#fef3c7; color:#92400e; }
    .badge-red { background:#fee2e2; color:#991b1b; }
    .kpi-grid { display:grid; grid-template-columns:repeat(4,1fr); gap:12px; margin-bottom:24px; }
    .kpi-card { background:#f8f8f8; border:1px solid #e8e8e8; border-radius:8px; padding:14px 16px; }
    .kpi-label { font-size:10px; font-weight:700; text-transform:uppercase; letter-spacing:1px; color:#888; margin-bottom:4px; }
    .kpi-value { font-size:18px; font-weight:900; color:#0B0E11; }
    .kpi-change-up { font-size:11px; color:#059669; font-weight:600; margin-top:4px; }
    .kpi-change-down { font-size:11px; color:#dc2626; font-weight:600; margin-top:4px; }
    .alert-box { background:#fffbeb; border:1px solid #fcd34d; border-radius:6px; padding:10px 14px; margin:4px 0; font-size:12px; color:#78350f; }
    @media print {
      body { padding: 20px 28px; }
      @page { margin: 1cm; }
    }
  </style>
`;function v(t,e=!0){let a=window.open("","_blank");a?(a.document.write(`<!DOCTYPE html><html lang="es"><head><meta charset="UTF-8">${m}<title>Informe J&A Contadores</title></head><body>${t}</body></html>`),a.document.close(),e&&(a.onload=()=>{a.focus(),a.print()},setTimeout(()=>{a.closed||(a.focus(),a.print())},800))):alert("Permite las ventanas emergentes para generar el informe.")}let u="#059669",b="#0F172A",f="#334155",y={background:"#FFFFFF",border:"1px solid #E2E8F0",borderRadius:"8px",boxShadow:"0 1px 3px rgba(15,23,42,0.04)",padding:"24px"};function k(){let{data:t,clientName:m,loading:k}=(0,p.useClient)(),[$,w]=(0,a.useState)("month"),[C,F]=(0,a.useState)(null);if(k||!t)return(0,e.jsxs)("div",{className:"p-8 flex items-center gap-3 text-slate-600",children:[(0,e.jsx)("div",{className:"w-5 h-5 border-2 rounded-full animate-spin",style:{borderColor:`${b}40`,borderTopColor:b}}),"Cargando Reportes..."]});let j=(e,a)=>{F(e),setTimeout(()=>{let i=m||"Mi Empresa";1===e?function(t,e,a,i=!0){let l=t.salesHistory.slice(-20).map(t=>`
    <tr><td>${t.date}</td><td style="text-align:right;font-weight:600;">${x(t.amount)}</td></tr>
  `).join(""),s=t.recurringCustomers.map((t,e)=>`
    <tr>
      <td>${e+1}</td>
      <td style="font-weight:600;">${t.name}</td>
      <td style="text-align:center;">${t.count}</td>
      <td style="text-align:right;font-weight:700;color:#059669;">${x(t.total)}</td>
    </tr>
  `).join(""),d=t.topProducts.map((t,e)=>`
    <tr>
      <td>${e+1}</td>
      <td style="font-weight:600;">${t.name}</td>
      <td style="text-align:center;">${t.count}</td>
      <td style="text-align:right;font-weight:700;">${x(t.total)}</td>
    </tr>
  `).join("");v(`
    ${g("Reporte de Ventas",`Per\xedodo: ${"week"===a?"Semana actual":"month"===a?"Mes actual":"Año actual"}`,e)}

    <div class="kpi-grid">
      <div class="kpi-card">
        <div class="kpi-label">Ventas Totales</div>
        <div class="kpi-value" style="font-size:15px;">${t.metrics.sales.value}</div>
        <div class="kpi-change-up">↑ ${t.metrics.sales.change}% vs per\xedodo anterior</div>
      </div>
      <div class="kpi-card">
        <div class="kpi-label">Facturas Emitidas</div>
        <div class="kpi-value">${t.metrics.productsSold.value}</div>
        <div class="kpi-change-up">↑ ${t.metrics.productsSold.change}%</div>
      </div>
      <div class="kpi-card">
        <div class="kpi-label">Clientes \xdanicos</div>
        <div class="kpi-value">${t.metrics.newClients.value}</div>
        <div class="kpi-change-up">↑ ${t.metrics.newClients.change}%</div>
      </div>
      <div class="kpi-card">
        <div class="kpi-label">Proyecci\xf3n 30 d\xedas</div>
        <div class="kpi-value" style="font-size:14px;">${x(t.prediction.nextMonth)}</div>
        <div class="kpi-change-up">Crecimiento: ${t.prediction.growthRate.toFixed(1)}%</div>
      </div>
    </div>

    <h2>Historial de Ventas (\xfaltimas 20 fechas)</h2>
    <table>
      <thead><tr><th>Fecha</th><th style="text-align:right;">Monto</th></tr></thead>
      <tbody>${l||'<tr><td colspan="2" style="text-align:center;color:#888;">Sin datos de historial</td></tr>'}</tbody>
    </table>

    <div style="display:grid;grid-template-columns:1fr 1fr;gap:20px;margin-top:8px;">
      <div>
        <h2>Top Clientes por Facturaci\xf3n</h2>
        <table>
          <thead><tr><th>#</th><th>Cliente</th><th style="text-align:center;">Facturas</th><th style="text-align:right;">Total</th></tr></thead>
          <tbody>${s||'<tr><td colspan="4" style="text-align:center;color:#888;">Sin datos</td></tr>'}</tbody>
        </table>
      </div>
      <div>
        <h2>Top Productos / Servicios</h2>
        <table>
          <thead><tr><th>#</th><th>Descripci\xf3n</th><th style="text-align:center;">Cant.</th><th style="text-align:right;">Total</th></tr></thead>
          <tbody>${d||'<tr><td colspan="4" style="text-align:center;color:#888;">Sin datos</td></tr>'}</tbody>
        </table>
      </div>
    </div>

    ${h()}
  `,i)}(t,i,$,a):2===e?function(t,e,a=!0){let i=t.taxData,l=i.monthlyBreakdown.map(t=>`
    <tr>
      <td style="font-weight:600;">${t.month}</td>
      <td style="text-align:right;">${x(t.ventas)}</td>
      <td style="text-align:right;">${x(t.iva)}</td>
      <td style="text-align:right;">${x(t.reteFuente)}</td>
      <td style="text-align:right;">${x(t.reteICA)}</td>
      <td style="text-align:right;font-weight:700;color:#059669;">${x(t.neto)}</td>
    </tr>
  `).join("");v(`
    ${g("Estado Financiero","Resumen de resultados y cartera",e)}

    <div class="kpi-grid">
      <div class="kpi-card">
        <div class="kpi-label">Ventas Brutas</div>
        <div class="kpi-value" style="font-size:14px;">${x(i.totalVentasBruto)}</div>
      </div>
      <div class="kpi-card">
        <div class="kpi-label">Impuestos Totales</div>
        <div class="kpi-value" style="font-size:14px;color:#dc2626;">${x(i.totalImpuestosCargo)}</div>
      </div>
      <div class="kpi-card">
        <div class="kpi-label">Cartera Total (Est.)</div>
        <div class="kpi-value" style="font-size:14px;">${t.portfolio.total}</div>
      </div>
      <div class="kpi-card">
        <div class="kpi-label">Cartera Vencida</div>
        <div class="kpi-value" style="font-size:14px;color:#dc2626;">${t.metrics.overdue.value}</div>
      </div>
    </div>

    <h2>Estado de Cartera</h2>
    <table>
      <thead><tr><th>Categor\xeda</th><th style="text-align:right;">Valor</th><th style="text-align:right;">%</th><th>Estado</th></tr></thead>
      <tbody>
        <tr><td>Cartera Vigente</td><td style="text-align:right;">${t.portfolio.current.value}</td><td style="text-align:right;">${t.portfolio.current.percent}%</td><td><span class="badge badge-green">✓ Al d\xeda</span></td></tr>
        <tr><td>Por Vencer</td><td style="text-align:right;">${t.portfolio.dueSoon.value}</td><td style="text-align:right;">${t.portfolio.dueSoon.percent}%</td><td><span class="badge badge-yellow">⚠ Pr\xf3xima</span></td></tr>
        <tr><td>Cartera Vencida</td><td style="text-align:right;">${t.portfolio.overdue.value}</td><td style="text-align:right;">${t.portfolio.overdue.percent}%</td><td><span class="badge badge-red">✗ Vencida</span></td></tr>
      </tbody>
    </table>

    <h2>Desglose Mensual</h2>
    <table>
      <thead><tr><th>Mes</th><th style="text-align:right;">Ventas</th><th style="text-align:right;">IVA</th><th style="text-align:right;">ReteFuente</th><th style="text-align:right;">ReteICA</th><th style="text-align:right;">Neto</th></tr></thead>
      <tbody>${l||'<tr><td colspan="6" style="text-align:center;color:#888;">Sin datos mensuales</td></tr>'}</tbody>
    </table>

    <h2>Proyecci\xf3n Financiera</h2>
    <table>
      <thead><tr><th>Indicador</th><th style="text-align:right;">Valor</th></tr></thead>
      <tbody>
        <tr><td>Proyecci\xf3n ventas pr\xf3ximos 30 d\xedas</td><td style="text-align:right;font-weight:700;">${x(t.prediction.nextMonth)}</td></tr>
        <tr><td>Tasa de crecimiento estimada</td><td style="text-align:right;font-weight:700;">${t.prediction.growthRate.toFixed(2)}%</td></tr>
        <tr><td>Tasa efectiva tributaria</td><td style="text-align:right;font-weight:700;">${i.tasaEfectivaTributaria}%</td></tr>
        <tr><td>Base gravable renta estimada</td><td style="text-align:right;font-weight:700;">${x(i.baseGravableRenta)}</td></tr>
        <tr><td>Impuesto de renta estimado (35%)</td><td style="text-align:right;font-weight:700;color:#dc2626;">${x(i.impuestoRentaEstimado)}</td></tr>
      </tbody>
    </table>

    ${h()}
  `,a)}(t,i,a):3===e?function(t,e,a=!0){let i=t.recurringCustomers.map((t,e)=>`
    <tr>
      <td>${e+1}</td>
      <td style="font-weight:600;">${t.name}</td>
      <td style="text-align:center;">${t.count}</td>
      <td style="text-align:right;">${x(t.total)}</td>
      <td style="text-align:right;">${x(t.total/Math.max(t.count,1))}</td>
    </tr>
  `).join(""),l=t.metrics.sales.rawValue;v(`
    ${g("Análisis de Clientes","Segmentación y comportamiento de clientes",e)}

    <div class="kpi-grid">
      <div class="kpi-card">
        <div class="kpi-label">Clientes \xdanicos</div>
        <div class="kpi-value">${t.metrics.newClients.value}</div>
      </div>
      <div class="kpi-card">
        <div class="kpi-label">Clientes Recurrentes</div>
        <div class="kpi-value">${t.recurringCustomers.filter(t=>t.count>1).length}</div>
      </div>
      <div class="kpi-card">
        <div class="kpi-label">Facturaci\xf3n Total</div>
        <div class="kpi-value" style="font-size:14px;">${t.metrics.sales.value}</div>
      </div>
      <div class="kpi-card">
        <div class="kpi-label">Ticket Promedio</div>
        <div class="kpi-value" style="font-size:14px;">${x(l/Math.max(t.metrics.productsSold.rawValue,1))}</div>
      </div>
    </div>

    <h2>Ranking de Clientes por Facturaci\xf3n</h2>
    <table>
      <thead>
        <tr>
          <th>#</th>
          <th>Nombre / Raz\xf3n Social</th>
          <th style="text-align:center;">Facturas</th>
          <th style="text-align:right;">Total Facturado</th>
          <th style="text-align:right;">Ticket Promedio</th>
        </tr>
      </thead>
      <tbody>${i||'<tr><td colspan="5" style="text-align:center;color:#888;">Sin datos de clientes</td></tr>'}</tbody>
    </table>

    <h2>Actividad Reciente</h2>
    <table>
      <thead><tr><th>Fecha</th><th>Cliente</th><th>Tipo</th><th style="text-align:right;">Monto</th></tr></thead>
      <tbody>
        ${t.recentActivity.map(t=>`
          <tr>
            <td>${t.time}</td>
            <td style="font-weight:600;">${t.client}</td>
            <td>${t.text}</td>
            <td style="text-align:right;font-weight:700;color:#059669;">${t.amount}</td>
          </tr>
        `).join("")}
      </tbody>
    </table>

    ${h()}
  `,a)}(t,i,a):4===e&&function(t,e,a=!0){let i=t.taxData,l=i.alertas.map(t=>`<div class="alert-box">${t}</div>`).join("");v(`
    ${g("Informe Tributario","Obligaciones fiscales estimadas — Ley Colombiana",e)}

    <div style="background:#fffbeb;border:2px solid #F0B90B;border-radius:8px;padding:10px 16px;margin-bottom:20px;font-size:11px;color:#78350f;">
      ⚠️ Este informe es una <strong>estimaci\xf3n referencial</strong>. Los valores no reemplazan una declaraci\xf3n oficial ante la DIAN. Cons\xfaltelo con su contador.
    </div>

    <div class="kpi-grid">
      <div class="kpi-card">
        <div class="kpi-label">Total Ventas Brutas</div>
        <div class="kpi-value" style="font-size:14px;">${x(i.totalVentasBruto)}</div>
      </div>
      <div class="kpi-card">
        <div class="kpi-label">IVA Generado</div>
        <div class="kpi-value" style="font-size:14px;">${x(i.totalIVACobrado)}</div>
      </div>
      <div class="kpi-card">
        <div class="kpi-label">IVA a Pagar (Est.)</div>
        <div class="kpi-value" style="font-size:14px;color:#dc2626;">${x(i.totalIVAPorPagar)}</div>
      </div>
      <div class="kpi-card">
        <div class="kpi-label">Tasa Efectiva</div>
        <div class="kpi-value">${i.tasaEfectivaTributaria}%</div>
      </div>
    </div>

    <h2>Resumen de Impuestos</h2>
    <table>
      <thead><tr><th>Impuesto</th><th>Base</th><th style="text-align:right;">Valor Estimado</th></tr></thead>
      <tbody>
        <tr><td>IVA Cobrado (19%)</td><td>Sobre ventas</td><td style="text-align:right;font-weight:700;">${x(i.totalIVACobrado)}</td></tr>
        <tr><td>IVA a Pagar (neto)</td><td>Cobrado - Descontable</td><td style="text-align:right;font-weight:700;color:#dc2626;">${x(i.totalIVAPorPagar)}</td></tr>
        <tr><td>Retenci\xf3n en la Fuente (3.5%)</td><td>Sobre ventas base</td><td style="text-align:right;font-weight:700;">${x(i.totalReteFuente)}</td></tr>
        <tr><td>ReteIVA (15%)</td><td>Sobre IVA</td><td style="text-align:right;font-weight:700;">${x(i.totalReteIVA)}</td></tr>
        <tr><td>ReteICA Bogot\xe1 (4.14‰)</td><td>Actividades comerciales</td><td style="text-align:right;font-weight:700;">${x(i.totalReteICA)}</td></tr>
        <tr style="background:#fff3cd;"><td style="font-weight:700;">Total Impuestos Cargo</td><td>—</td><td style="text-align:right;font-weight:900;color:#dc2626;">${x(i.totalImpuestosCargo)}</td></tr>
      </tbody>
    </table>

    <h2>Impuesto de Renta (Estimado)</h2>
    <table>
      <thead><tr><th>Concepto</th><th style="text-align:right;">Valor</th></tr></thead>
      <tbody>
        <tr><td>Base Gravable</td><td style="text-align:right;">${x(i.baseGravableRenta)}</td></tr>
        <tr><td>Impuesto de Renta estimado (35%)</td><td style="text-align:right;font-weight:700;color:#dc2626;">${x(i.impuestoRentaEstimado)}</td></tr>
        <tr><td>R\xe9gimen Sugerido</td><td style="text-align:right;font-weight:700;">${i.regimenSugerido}</td></tr>
      </tbody>
    </table>

    <h2>Declaraciones Peri\xf3dicas</h2>
    <table>
      <thead><tr><th>Tipo</th><th style="text-align:right;">Valor Estimado</th></tr></thead>
      <tbody>
        <tr><td>IVA Bimestral (promedio)</td><td style="text-align:right;font-weight:700;">${x(i.ivaDeclaracionBimestral)}</td></tr>
        <tr><td>IVA Cuatrimestral (promedio)</td><td style="text-align:right;font-weight:700;">${x(i.ivaDeclaracionCuatrimestral)}</td></tr>
        <tr><td>Total Facturas analizadas</td><td style="text-align:right;">${i.totalFacturas}</td></tr>
      </tbody>
    </table>

    ${i.alertas.length>0?`<h2>Alertas y Recomendaciones</h2>${l}`:""}

    ${h()}
  `,a)}(t,i,a),F(null)},100)},N=[{id:1,title:"Reporte de Ventas",description:"Análisis detallado de ventas, historial y top clientes por período",icon:r.ShoppingCart,color:b,bgColor:"#CCFBF1",lastGenerated:new Date().toLocaleDateString(),dataPoints:`${t.metrics.productsSold.value} facturas \xb7 ${t.metrics.newClients.value} clientes`},{id:2,title:"Estado Financiero",description:"Resumen de cartera, métricas financieras y proyección de ingresos",icon:d.DollarSign,color:f,bgColor:"#E0F2FE",lastGenerated:new Date().toLocaleDateString(),dataPoints:`Cartera: ${t.portfolio.total} \xb7 ${t.portfolio.current.percent}% al d\xeda`},{id:3,title:"Análisis de Clientes",description:"Segmentación, recurrencia y comportamiento de clientes por facturación",icon:o.Users,color:u,bgColor:"#D1FAE5",lastGenerated:new Date().toLocaleDateString(),dataPoints:`${t.recurringCustomers.length} clientes analizados`},{id:4,title:"Informe Tributario",description:"Estimación de IVA, retenciones y renta anual según Ley Colombiana",icon:s.TrendingUp,color:"#3B82F6",bgColor:"#FEF3C7",lastGenerated:new Date().toLocaleDateString(),dataPoints:`IVA: ${(t.taxData.totalIVACobrado/1e6).toFixed(1)}M \xb7 Renta est.`}],A=[{label:"Ventas Totales",value:t.metrics.sales.value,color:b,bgColor:"#CCFBF1",icon:d.DollarSign},{label:"Facturas Generadas",value:t.metrics.productsSold.value,color:f,bgColor:"#E0F2FE",icon:l.FileText},{label:"Clientes Activos",value:t.metrics.newClients.value,color:u,bgColor:"#D1FAE5",icon:o.Users},{label:"Cartera Vencida",value:t.portfolio.overdue.value,color:"#DC2626",bgColor:"#FEE2E2",icon:s.TrendingUp}];return(0,e.jsxs)("div",{className:"space-y-6 pb-10",style:{fontFamily:"var(--font-inter)"},children:[(0,e.jsxs)("div",{className:"flex flex-col sm:flex-row sm:items-center justify-between gap-4",children:[(0,e.jsxs)("div",{children:[(0,e.jsxs)("h1",{className:"text-2xl font-black text-slate-800",style:{fontFamily:"var(--font-outfit)"},children:["Centro de ",(0,e.jsx)("span",{style:{color:b},children:"Reportes"})]}),(0,e.jsx)("p",{className:"text-slate-400 text-sm mt-1",children:"Genera informes financieros completos en PDF — datos reales del cliente"})]}),(0,e.jsx)("div",{className:"flex items-center gap-1 p-1 rounded-xl",style:{background:"#F8FAFC",border:"1.5px solid #E2E8F0"},children:[{id:"week",label:"Esta Semana"},{id:"month",label:"Este Mes"},{id:"year",label:"Este Año"}].map(t=>(0,e.jsx)("button",{onClick:()=>w(t.id),className:"px-3 py-1.5 text-xs font-bold rounded-lg transition-all",style:$===t.id?{background:f,color:"white",boxShadow:"0 2px 8px rgba(11,36,71,0.3)"}:{color:"#64748B"},children:t.label},t.id))})]}),(0,e.jsx)("div",{className:"grid grid-cols-2 lg:grid-cols-4 gap-4",children:A.map((t,a)=>(0,e.jsxs)("div",{style:y,className:"hover:-translate-y-0.5 transition-transform",children:[(0,e.jsxs)("div",{className:"flex items-center justify-between mb-3",children:[(0,e.jsx)("p",{className:"text-slate-400 text-[10px] uppercase font-bold tracking-wider",children:t.label}),(0,e.jsx)("div",{className:"w-8 h-8 rounded-lg flex items-center justify-center",style:{background:t.bgColor},children:(0,e.jsx)(t.icon,{className:"w-4 h-4",style:{color:t.color}})})]}),(0,e.jsx)("p",{className:"font-black text-xl font-mono",style:{color:t.color},children:t.value})]},a))}),(0,e.jsx)("div",{className:"grid grid-cols-1 md:grid-cols-2 gap-5",children:N.map(t=>{let a=t.icon,l=C===t.id;return(0,e.jsx)("div",{style:y,className:"group hover:-translate-y-1 transition-all duration-200 hover:shadow-lg",children:(0,e.jsxs)("div",{className:"flex items-start gap-4",children:[(0,e.jsx)("div",{className:"w-12 h-12 rounded-2xl flex items-center justify-center flex-shrink-0 transition-transform group-hover:scale-110 duration-300",style:{background:t.bgColor},children:(0,e.jsx)(a,{className:"w-6 h-6",style:{color:t.color}})}),(0,e.jsxs)("div",{className:"flex-1 min-w-0",children:[(0,e.jsx)("h3",{className:"font-black text-slate-800 text-base mb-1",children:t.title}),(0,e.jsx)("p",{className:"text-slate-500 text-xs leading-relaxed mb-3",children:t.description}),(0,e.jsxs)("div",{className:"flex items-center gap-2 flex-wrap mb-4",children:[(0,e.jsxs)("span",{className:"text-[9px] px-2 py-0.5 rounded-full font-bold",style:{background:"#F1F5F9",color:"#64748B"},children:["📊 ",t.dataPoints]}),(0,e.jsxs)("span",{className:"text-[9px] text-slate-400",children:["Generado: ",t.lastGenerated]})]}),(0,e.jsxs)("div",{className:"flex items-center gap-2",children:[(0,e.jsx)("button",{onClick:()=>j(t.id,!1),disabled:l,className:"flex items-center gap-1.5 px-3 py-2 text-xs font-bold rounded-xl transition-all hover:opacity-90 active:scale-95 disabled:opacity-50",style:{background:t.color,color:"white",boxShadow:`0 4px 12px ${t.color}40`},children:l?(0,e.jsxs)(e.Fragment,{children:[(0,e.jsx)(c.Loader2,{className:"w-3.5 h-3.5 animate-spin"})," Generando..."]}):(0,e.jsxs)(e.Fragment,{children:[(0,e.jsx)(n.Eye,{className:"w-3.5 h-3.5"})," Vista Previa"]})}),(0,e.jsxs)("button",{onClick:()=>j(t.id,!0),disabled:l,className:"flex items-center gap-1.5 px-3 py-2 text-xs font-bold rounded-xl transition-all hover:bg-slate-100 active:scale-95 disabled:opacity-50",style:{background:"#F8FAFC",color:"#64748B",border:"1.5px solid #E2E8F0"},children:[(0,e.jsx)(i,{className:"w-3.5 h-3.5"})," Imprimir PDF"]})]})]})]})},t.id)})}),(0,e.jsxs)("div",{style:y,children:[(0,e.jsxs)("div",{className:"flex items-center justify-between mb-4",children:[(0,e.jsx)("h3",{className:"font-bold text-slate-800 text-sm",children:"Actividad Reciente del Cliente"}),(0,e.jsxs)("span",{className:"text-[10px] font-bold px-2 py-0.5 rounded-lg",style:{background:"#CCFBF1",color:"#0F766E"},children:["Últimas ",t.recentActivity.length," transacciones"]})]}),(0,e.jsx)("div",{className:"space-y-2",children:t.recentActivity.length>0?t.recentActivity.map((t,a)=>(0,e.jsxs)("div",{className:"flex items-center justify-between p-3 rounded-xl hover:bg-slate-50 transition-colors",style:{border:"1px solid #F1F5F9"},children:[(0,e.jsxs)("div",{className:"flex items-center gap-3 min-w-0",children:[(0,e.jsx)("div",{className:"w-8 h-8 rounded-xl flex items-center justify-center flex-shrink-0",style:{background:`${b}15`},children:(0,e.jsx)("div",{className:"w-2 h-2 rounded-full",style:{background:b}})}),(0,e.jsxs)("div",{className:"min-w-0",children:[(0,e.jsx)("p",{className:"text-slate-700 text-sm font-semibold truncate",children:t.text}),(0,e.jsx)("p",{className:"text-slate-400 text-xs truncate",children:t.client})]})]}),(0,e.jsxs)("div",{className:"text-right flex-shrink-0 ml-4",children:[(0,e.jsx)("p",{className:"font-black text-sm font-mono",style:{color:b},children:t.amount}),(0,e.jsx)("p",{className:"text-slate-400 text-xs",children:t.time})]})]},a)):(0,e.jsx)("div",{className:"text-center py-8 text-slate-400 text-sm",children:"Sin actividad reciente registrada"})})]})]})}t.s(["default",()=>k],8112)}]);